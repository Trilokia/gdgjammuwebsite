<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Google Developer Group Jammu</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="./css/style.css" />
    <meta name="keywords" content="GDG Jammu, Google Developer Group Jammu" >

<!-- Favicons -->
<link rel="apple-touch-icon" sizes="57x57" href="images/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="images/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="images/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
<link rel="manifest" href="images/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="images/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">
    <script
      src="https://kit.fontawesome.com/8cb3487569.js"
      crossorigin="anonymous"
    ></script>
    <script defer src="./index.js"></script>
  </head>
  <body>
    <header>
      <input type="checkbox" id="nav-toggle" class="nav-toggle" />
      <label for="nav-toggle" class="nav-toggle-icon">
        <span></span>
      </label>

      <a class="nav-logo-link" href="#"
        ><img
          class="nav-logo"
          src="images/gdg-jammu.png"
          alt="Google Developers logo"
      /></a>

      <nav class="primary-nav">
        <div class="dropdown">
        <div class="dropdown-item">
            <button class="dropdown-btn events" onclick="redirectToHomePage()">Home</button>
          </div>
          <div class="dropdown-item">
            <button class="dropdown-btn events" onclick="redirectToDevfest22()">Devfest Jammu 2023</button>
          </div>
          <div class="dropdown-item">
            <button class="dropdown-btn events" onclick="redirectToRecent()">Recents Events</button>
          </div>
         <!-- <div class="dropdown-item">
            <button class="dropdown-btn events" onclick="redirectToWomenTechmaker() ">Our Collaboration</button>
          </div>-->
          <div class="dropdown-item">
            <button class="dropdown-btn learn" onclick="redirectToCommunity()">Impowering Community</button>
          </div>
          
         <div class="dropdown-item">
            <button class="dropdown-btn learn" onclick="redirectToAbout()">About Google Developer Groups</button>
          </div>

           <!--<div class="dropdown-item products">
          
            <button class="dropdown-btn" onclick="redirectToAbout">About GDG</button>
          <span class="dropdown-arrow"></span>
            <ul class="dropdown-links">
              <li><a class="dropdown-link" href="https://developers.google.com/">Organizer</a></li>
              <li><a class="dropdown-link" href="#">Team</a></li>
              <li><a class="dropdown-link" href="#">Earn</a></li>
            </ul>
          </div>-->

         <!--<div class="dropdown-item more">
            <button class="dropdown-btn">Blog</button>
            <ul class="dropdown-links">
              <li>
                <a class="dropdown-link" href="#">Developer Coommunities</a>
              </li>
              <li><a class="dropdown-link" href="#">Developer Profile</a></li>
            </ul>
            <span class="dropdown-arrow"></span>
          </div>-->
        </div>
      </nav>

      <div class="secondary-nav">
       <!--<div class="searchbar">
          <button class="searchbar-icon">
            <i class="fas fa-search"></i>
          </button>
          <input
            type="text"
            class="searchbar-input"
            placeholder="Search"
            aria-label="search"
          />
          <label class="searchbar-close-icon">
            <i class="fas fa-times"></i>
          </label>
        </div>-->

        <!--<div class="custom-select">
          <select class="select-lan">
            <option>English</option>
            <option>中文</option>
            <option>日本語</option>
          </select>
          <span class="select-arrow"></span>
        </div>-->

        <button class="dot-btn"><i class="fas fa-info"></i></button>
        <!--<button class="user-btn">E</button>-->
      </div>
    </header>

    <main>
      <div class="container">
        <div class="banner-message">
          <div class="banner-message-text">
            <span>
              Connect with fellow devs and learn how to build with Google.
            </span>
            <a href="https://devfestindia.com/">Find a DevFest near you.</a>
          </div>
        </div>


        
        <!-- ------------------------  Hero Section  ------------------------ -->

        <section class="hero">
        <div class="hero-img">
            <img src="images/colloboration.gif" alt="graphics" style="margin-left:auto;
            margin-right: auto;" />
          </div>
          <div class="hero-text">
            <h3 class="hero-text-title">
            Our Collaboration
            </h3>
            <p class="hero-text-body">
            We collaborates across J&K, uniting through technology for positive change, community empowerment, and lasting socio-economic impact. Join us!
            </p>
            <a class="hero-text-button" href="https://gdg.community.dev/gdg-jammu/">Partner with us</a>
          </div>
          
        </section>

        
        <!-- ------------------------  Products Section  ------------------------ -->

      <section class="products-list">
      
        <div class="products-group">
            <div class="products-item">
              <div class="products-item-icon">
                <a href="https://developer.android.com" target="_blank">
                  <img src="./images/iitjammu.png" alt="android" />
                </a>
              </div>
              <div class="products-item-description">
                <p>Android</p>
              </div>
            </div>

            <div class="products-item">
              <div class="products-item-icon">
                <a href="https://cloud.google.com/developers" target="_blank">
                  <img
                    src="./css/img/google_cloud_64dp.png"
                    alt="Google Cloud"
                  />
                </a>
              </div>
              <div class="products-item-description">
                <p>Google Cloud</p>
              </div>
            </div>

            <div class="products-item">
              <div class="products-item-icon">
                <a href="https://firebase.google.com/docs" target="_blank">
                  <img src="./css/img/firebase_64dp.png" alt="Firebase" />
                </a>
              </div>
              <div class="products-item-description">
                <p>Firebase</p>
              </div>
            </div>

            <div class="products-item">
              <div class="products-item-icon">
                <a href="https://flutter.dev/docs" target="_blank">
                  <img src="./css/img/flutter_64dp.png" alt="Flutter" />
                </a>
              </div>
              <div class="products-item-description">
                <p>Flutter</p>
              </div>
            </div>

         

         



        

      

          

          </div>
          <!-- end products group -->
        
        </section>


      


   
         
       
         
         
       
  
<section class="community-guidlines">
  <div class="community-guidlines-container">
    <div class="community-guidlines-text">
      <h3 class="community-guidlines-text-title">
        Our community guidelines
      </h3>
      <p class="community-guidlines-description">
        Google is dedicated to providing a harassment-free and inclusive event experience for everyone regardless of gender identity and expression, sexual orientation, disabilities, neurodiversity, physical appearance, body size, ethnicity, nationality, race, age, religion, or other protected category.
  
      </p>
      <a href="https://developers.google.com/community-guidelines" class="community-guidlines-cta
      ">Read our community guidelines</a>
    </div>
  </div>
  </section>
      </div>
    </main>

<?php 
include 'footer.php';
?>
 
    <script>
     function redirectToHomePage() {
          // Change the window location to the desired URL
          window.location.href = "index.php";
      }
      function redirectToDevfest22() {
          // Change the window location to the desired URL
          window.location.href = "https://devfest.gdgjammu.com/";
      }
      function redirectToAbout() {
          // Change the window location to the desired URL
          window.location.href = "https://developers.google.com/community/gdg";
      }
       function redirectToWomenTechmaker() {
          // Change the window location to the desired URL
          window.location.href = "https://gdg.community.dev/events/details/google-gdg-jammu-presents-international-womens-day-iwd-jammu-2023/";
      }
       function redirectToCommunity() {
          // Change the window location to the desired URL
          window.location.href = "community.php";
      }
      function redirectToRecent() {
          // Change the window location to the desired URL
          window.location.href = "recent.php";
      }
  </script>
  </body>
  
</html>
